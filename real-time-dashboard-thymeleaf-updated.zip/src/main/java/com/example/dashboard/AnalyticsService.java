package com.example.dashboard;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class AnalyticsService {

    private final AnalyticsRepository analyticsRepository;
    private final AnalyticsController analyticsController;

    public AnalyticsService(AnalyticsRepository analyticsRepository, AnalyticsController analyticsController) {
        this.analyticsRepository = analyticsRepository;
        this.analyticsController = analyticsController;
    }

    @KafkaListener(topics = "analytics-topic", groupId = "dashboard-group")
    public void listen(Analytics analytics) {
        analyticsRepository.save(analytics);
        analyticsController.sendUpdate(analytics);
    }
}
