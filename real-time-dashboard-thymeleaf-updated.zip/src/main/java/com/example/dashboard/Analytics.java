package com.example.dashboard;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "analytics")
public class Analytics {
    @Id
    private String id;
    private String metric;
    private Double value;
    private Long timestamp;
    
    // getters and setters
}
