package com.example.dashboard;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AnalyticsController {

    private final SimpMessagingTemplate messagingTemplate;

    public AnalyticsController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void sendUpdate(Analytics analytics) {
        messagingTemplate.convertAndSend("/topic/analytics", analytics);
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }
}
